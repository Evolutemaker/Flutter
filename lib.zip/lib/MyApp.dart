import 'package:flutter/material.dart';
import 'package:ozen/bottombar.dart';
import 'package:ozen/pages/SignInPage.dart';
import 'package:ozen/services/auth.dart';
import 'package:ozen/services/root_page.dart';
import 'data.dart';
import 'Page_indicator.dart';
import 'package:ozen/pages/Home.dart';
import 'package:page_transition/page_transition.dart';
//import 'package:gradient_text/gradient_text.dart';
class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with TickerProviderStateMixin{
  PageController _controller;
  int currentPage = 0;
  bool lastPage = false;
  AnimationController animationController;
  Animation<double> _scaleAnimation;
  bool _textVisible = true;
  @override
  void initState() {
    super.initState();
    _controller = PageController(
      initialPage: currentPage,

    );

    animationController =
        AnimationController(duration: Duration(milliseconds: 300), vsync: this);
    _scaleAnimation = Tween(begin: 0.6, end: 1.0).animate(animationController);



    animationController = AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 100)
    );
    _scaleAnimation = Tween<double>(
        begin: 1.0,
        end: 25.0
    ).animate(animationController);
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }



  void _onTap() {
    setState(() {
      _textVisible = false;
    });
    animationController.forward().then((f) =>
        Navigator.push(context, PageTransition(type: PageTransitionType.fade, child: RootPage(auth: Auth())))
    );
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [Color(0xFF485563),/* Color(0xFF29323C),*/ Color.fromRGBO(4, 4, 4, 1) ],
            tileMode: TileMode.clamp,
            begin: Alignment.topCenter,
            stops: [0.0, 1.0],
            end: Alignment.bottomCenter),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: new Stack(
          fit: StackFit.expand,
          children: <Widget>[
            PageView.builder(
              itemCount: pageList.length,
              controller: _controller,
              onPageChanged: (index) {
                setState(() {
                  currentPage = index;
                  if (currentPage == pageList.length - 1) {
                    lastPage = true;
                    animationController.forward();
                  } else {
                    lastPage = false;
                    animationController.reset();
                  }
                  print(lastPage);
                });
              },
              itemBuilder: (context, index) {
                return AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    var page = pageList[index];
                    var delta;
                    var y = 1.0;

                    if (_controller.position.haveDimensions) {
                      delta = _controller.page - index;
                      y = 1 - delta.abs().clamp(0.0, 1.0);
                    }
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      // mainAxisSize: MainAxisSize.min,
                      children: <Widget>[



                        Padding(
                          padding: EdgeInsets.only(left: 10,top: 250 ),
                          child: Image.asset(page.imageUrl, width: 400, height: 220,),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(left: 34.0, top: 12.0),
                          child: Transform(
                            transform:
                            Matrix4.translationValues(0, 50.0 * (1 - y), 0),
                            child: Text(
                              page.body,
                              style: TextStyle(
                                  fontSize: 30.0,
                                  fontFamily: "Brownfox",
                                  color: Colors.white),
                            ),
                          ),
                        ),


                      ],
                    );
                  },
                );
              },
            ),
            Positioned(
              left: 30.0,
              bottom: 55.0,
              child: Container(
                  width: 160.0,
                  child: PageIndicator(currentPage, pageList.length)),
            ),
            Positioned(
              right: 30.0,
              bottom: 30.0,
              //  child: ScaleTransition(
              //  scale: _scaleAnimation,
              child: lastPage
                  ? FloatingActionButton(
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.arrow_forward,
                  color: Colors.black,

                ),
                onPressed: () {
                  _onTap();
                },
              )
                  : Container(),
              //),
            ),
          ],
        ),
      ),
    );
  }
}
