import 'package:flutter/material.dart';

var pageList = [

  PageModel(
      imageUrl: "assets/images/welcome.png",
      body: "Добро пожаловать на õzen stream",

      //titleGradient: gradients[0]
  ),
  PageModel(
      imageUrl: "assets/images/music.png",
      body: "Казахстанская музыка,   авторские передачи,       топ-чарты  ",

      //titleGradient: gradients[1]
  ),
  PageModel(
      imageUrl: "assets/images/connect.png",
      body: "Подключайся и будь на связи!",

      //titleGradient: gradients[2]
  ),
];
/*
List<List<Color>> gradients = [
  [Color(0xFF9708CC), Color(0xFF43CBFF)],
  [Color(0xFFE2859F), Color(0xFFFCCF31)],
  [Color(0xFF5EFCE8), Color(0xFF736EFE)],
];
*/
class PageModel {
  var imageUrl;
  var body;

  List<Color> titleGradient = [];
  PageModel({this.imageUrl,  this.body,/*this.titleGradient*/});
}
