import 'package:flutter/material.dart';
import 'package:ozen/MyApp.dart';

//import 'package:gradient_text/gradient_text.dart';



void main() => runApp(
    MaterialApp(
   home: MyApp(),
   theme: ThemeData(
      fontFamily: "Brownfox"
   ),
   debugShowCheckedModeBanner: false,
));
