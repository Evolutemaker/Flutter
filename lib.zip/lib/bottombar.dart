import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:ozen/pages/Chat.dart';
import 'package:ozen/pages/Favorite.dart';
import 'package:ozen/pages/Home.dart';
import 'package:ozen/services/auth.dart';

class Bottombar extends StatefulWidget {
  Bottombar({this.auth, this.onSignOut});
  final BaseAuth auth;
  final VoidCallback onSignOut;
  static final String id = 'profile_page';

  @override
  _BottombarState createState() => _BottombarState();
}

class _BottombarState extends State<Bottombar> {

  final _pageController = PageController();
  int index = 1;

  @override
  void initState() {
    super.initState();

  }
/*
  signOut() async {
    try {
      await widget.auth.signOut();
      widget.logoutCallback();
    } catch (e) {
      print(e);
    }
  }
  */
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: PageView(

          controller: _pageController,
          children: <Widget>[
            Home(),
            Favorite(),
            Chat(),
          ],
          onPageChanged: (int index) {
            setState(() {

              _pageController.jumpToPage(index);
            });
          }
      ),


      bottomNavigationBar: CurvedNavigationBar(
        animationCurve: Curves.easeInOutBack,

        index:0,

        items: <Widget>[
          Icon(Icons.radio, size: 32, color: Color.fromRGBO(4, 4, 4, 1), ),
          Icon(Icons.favorite, size: 32, color: Color.fromRGBO(4, 4, 4, 1)),
          Icon(Icons.chat, size: 32, color: Color.fromRGBO(4, 4, 4, 1)),
        ],
        color: Colors.white,
        backgroundColor: Color.fromRGBO(4, 4, 4, 1),
        height: 60.0,
        onTap: (int index) {
          setState(() {
            _pageController.jumpToPage(index);
          });
        },

      ),
    );

  }
}
