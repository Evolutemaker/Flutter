


class Track{

    final String currenttrack;
    Track({ this.currenttrack});

    factory Track.fromJson(final json){
        return Track(

            currenttrack: json["current_track"]
        );
    }
}