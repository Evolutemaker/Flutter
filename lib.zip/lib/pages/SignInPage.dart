import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:ozen/services/auth.dart';


class SignInPage extends StatefulWidget {
  SignInPage({Key key, this.title, this.auth, this.onSignIn}) : super(key: key);

  final String title;
  final BaseAuth auth;
  final VoidCallback onSignIn;
  @override
  _SignInPageState createState() => _SignInPageState();
}


enum FormType {
  login,
  register
}
class _SignInPageState extends State<SignInPage> {


  static final formKey = new GlobalKey<FormState>();

  String _email;
  String _password;
  FormType _formType = FormType.login;
  String _authHint = '';

  bool validateAndSave() {
    final form = formKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  void validateAndSubmit() async {
    if (validateAndSave()) {
      try {
        String userId = _formType == FormType.login
            ? await widget.auth.signIn(_email, _password)
            : await widget.auth.createUser(_email, _password);
        setState(() {
          _authHint = 'Signed In\n\nUser id: $userId';
        });
        widget.onSignIn();
      }
      catch (e) {
        setState(() {
          _authHint = 'Sign In Error\n\n${e.toString()}';
        });
        print(e);
      }
    } else {
      setState(() {
        _authHint = '';
      });
    }
  }




  MediaQueryData queryData;
  Color orangec = Color(0xffF04A55);
  Color greyc = Color(0xff494F58);
  Color bluec = Color(0xffB2D4A2);

  @override
  Widget build(BuildContext context) {
    queryData = MediaQuery.of(context);
    return Scaffold(
      body: SingleChildScrollView(
        child: CustomPaint(
          painter: SignInPainter(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: queryData.size.width * 0.2),

              Row(
                children: <Widget>[
                  SizedBox(width: queryData.size.width * 0.07),
                  Text(
                    'Вход',
                    style: TextStyle(
                      fontSize: queryData.size.width * 0.15,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),

              SizedBox(height: queryData.size.width * 0.22),
              Padding(
                padding: EdgeInsets.all(queryData.size.width * 0.07),
                child: Form(
                  child: Column(
                    children: <Widget>[
                      SizedBox(height: queryData.size.width * 0.2),
                      TextFormField(
                        key: new Key('email'),
                        autocorrect: false,
                        validator: (val) => val.isEmpty ? 'Email can\'t be empty.' : null,
                        onSaved: (val) => _email = val,
                        decoration: InputDecoration(
                           labelText: 'Email',
                         // hintText: 'Email',
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: queryData.size.width * 0.05,
                          ),
                        ),
                      ),
                      SizedBox(height: queryData.size.width * 0.05),
                      TextFormField(
                        key: new Key('password'),
                        obscureText: true,
                        autocorrect: false,
                        validator: (val) => val.isEmpty ? 'Password can\'t be empty.' : null,
                        onSaved: (val) => _password = val,
                        decoration: InputDecoration(
                          labelText: 'Password',
                          //hintText: 'Password',
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: queryData.size.width * 0.05,
                          ),
                        ),
                      ),
                      SizedBox(height: queryData.size.width * 0.05),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            'Войти',
                            style: TextStyle(
                              fontSize: queryData.size.width * 0.09,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          ClipOval(
                            child: Material(
                              color: greyc,
                              child: InkWell(
                                child: Padding(
                                  padding: EdgeInsets.all(
                                      queryData.size.width * 0.07),
                                  child: GestureDetector(
                                    onTap: validateAndSubmit,
                                    child: Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white,
                                    ),
                                  )
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: queryData.size.width * 0.05),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          InkWell(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => SignUpPage(),
                                ),
                              );
                            },
                            child: Text(
                              'Регистрация',
                              style: TextStyle(
                                fontSize: queryData.size.width * 0.05,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),

                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SignInPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const Color orangec = Color(0xffF04A55);
    const Color greyc = Color(0xFF485563);
    const Color bluec = Color(0xffB2D4A2);

    var paint = Paint();

    paint.color = bluec;

    Offset c1 = Offset(size.width * 1.0, size.width * 0.01);
    double radius1 = size.width * 1.1;

    canvas.drawCircle(c1, radius1, paint);

    paint.color = greyc;

    Offset c2 = Offset(size.width * 0.05, size.width * 0.05);
    double radius2 = size.width * 0.9;

    canvas.drawCircle(c2, radius2, paint);

    paint.color = orangec;

    Offset c3 = Offset(size.width * 0.0, size.width * 0.0);
    double radius3 = size.width * 0.5;

    canvas.drawCircle(c3, radius3, paint);
  }

  @override
  bool shouldRepaint(SignInPainter oldDelegate) => false;

  @override
  bool shouldRebuildSemantics(SignInPainter oldDelegate) => false;
}

class SignUpPage extends StatefulWidget {
  SignUpPage({Key key, this.title, this.auth, this.onSignIn}) : super(key: key);

  final String title;
  final BaseAuth auth;
  final VoidCallback onSignIn;
  @override
  _SignUpPageState createState() => _SignUpPageState();
}


class _SignUpPageState extends State<SignUpPage> {


  static final formKey = new GlobalKey<FormState>();

  String _email;
  String _password;
  FormType _formType = FormType.login;
  String _authHint = '';

  bool validateAndSave() {
    final form = formKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  void validateAndSubmit() async {
    if (validateAndSave()) {
      try {
        String userId = _formType == FormType.login
            ? await widget.auth.signIn(_email, _password)
            : await widget.auth.createUser(_email, _password);
        setState(() {
          _authHint = 'Signed In\n\nUser id: $userId';
        });
        widget.onSignIn();
      }
      catch (e) {
        setState(() {
          _authHint = 'Sign In Error\n\n${e.toString()}';
        });
        print(e);
      }
    } else {
      setState(() {
        _authHint = '';
      });
    }
  }



  MediaQueryData queryData;
  Color orangec = Color(0xffF04A55);
  Color greyc = Color(0xFF485563);
  Color bluec = Color(0xffB2D4A2);

  @override
  Widget build(BuildContext context) {
    queryData = MediaQuery.of(context);
    return Scaffold(
      body: SingleChildScrollView(
        child: CustomPaint(
          painter: SignUpPainter(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: queryData.size.width * 0.1),

              SizedBox(height: queryData.size.width * 0.05),
              Row(
                children: <Widget>[
                  SizedBox(width: queryData.size.width * 0.07),
                  Text(
                    'Cоздать',
                    style: TextStyle(
                      fontSize: queryData.size.width * 0.11,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              Row(
                children: <Widget>[
                  SizedBox(width: queryData.size.width * 0.07),
                  Text(
                    'Aккаунт',
                    style: TextStyle(
                      fontSize: queryData.size.width * 0.11,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsets.all(queryData.size.width * 0.07),
                child: Form(
                  child: Column(
                    children: <Widget>[
                      SizedBox(height: queryData.size.width * 0.1),
                      SizedBox(height: queryData.size.width * 0.27),
                      TextFormField(
                        key: new Key('email'),
                        autocorrect: false,
                        validator: (val) => val.isEmpty ? 'Email can\'t be empty.' : null,
                        onSaved: (val) => _email = val,
                        decoration: InputDecoration(
                          labelText: 'Email',
                         // hintText: 'Email',
                          hintStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: queryData.size.width * 0.05,
                            color: Colors.white,
                          ),
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: queryData.size.width * 0.05,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      SizedBox(height: queryData.size.width * 0.05),
                      TextFormField(
                        key: new Key('password'),
                        obscureText: true,
                        autocorrect: false,
                        validator: (val) => val.isEmpty ? 'Password can\'t be empty.' : null,
                        onSaved: (val) => _password = val,
                        decoration: InputDecoration(
                          labelText: 'Password',
                         // hintText: 'Password',
                          hintStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: queryData.size.width * 0.05,
                            color: Colors.white,
                          ),
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: queryData.size.width * 0.05,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      SizedBox(height: queryData.size.width * 0.05),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            'Регистрация',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: queryData.size.width * 0.09,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          ClipOval(
                            child: Material(
                              color: greyc,
                              child: InkWell(
                                child: Padding(
                                  padding: EdgeInsets.all(
                                      queryData.size.width * 0.07),
                                  child: GestureDetector(
                                    onTap: validateAndSubmit,
                                    child: Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white,
                                    ),
                                  )
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: queryData.size.width * 0.05),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          InkWell(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => SignInPage(),
                                ),
                              );
                            },
                            child: Text(
                              'Уже зарегистрированы?',
                              style: TextStyle(
                                fontSize: queryData.size.width * 0.05,
                                decoration: TextDecoration.underline,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SignUpPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const Color orangec = Color(0xffF04A55);
    const Color greyc = Color(0xff485563);
    const Color bluec = Color(0xffB2D4A2);

    var paint = Paint();

    paint.color = bluec;

    Offset c1 = Offset(size.width * 0.15, size.width * 0.8);
    double radius1 = size.width * 1.0;

    canvas.drawCircle(c1, radius1, paint);

    paint.color = greyc;

    Offset c2 = Offset(size.width * 0.2, size.height * 0.02);
    double radius2 = size.width * 0.9;

    canvas.drawCircle(c2, radius2, paint);
  }

  @override
  bool shouldRepaint(SignInPainter oldDelegate) => true;

  @override
  bool shouldRebuildSemantics(SignInPainter oldDelegate) => true;
}
