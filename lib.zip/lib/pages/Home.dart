import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter_radio/flutter_radio.dart';
import 'package:http/http.dart' as http;
import 'package:ozen/Track.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:ozen/services/auth.dart';


class Home extends StatefulWidget {

  Home({this.auth, this.onSignOut});
  final BaseAuth auth;
  final VoidCallback onSignOut;
  @override
  _HomeState createState() => _HomeState();

}

class _HomeState extends State<Home> {


  String url = "https://streaming.radio.co/scc370f2b2/listen";

  bool isPlaying = false;
  bool isVisible = true;

  Future<void> audioStart() async {
    await FlutterRadio.audioStart();

  }

  @override
  void initState() {
    super.initState();
    audioStart();
    //_checkEmailVerification();
    getCurrentTag();
  }



















  final FirebaseDatabase _database = FirebaseDatabase.instance;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();




  //bool _isEmailVerified = false;



//  void _checkEmailVerification() async {
//    _isEmailVerified = await widget.auth.isEmailVerified();
//    if (!_isEmailVerified) {
//      _showVerifyEmailDialog();
//    }
//  }

//  void _resentVerifyEmail(){
//    widget.auth.sendEmailVerification();
//    _showVerifyEmailSentDialog();
//  }

//  void _showVerifyEmailDialog() {
//    showDialog(
//      context: context,
//      builder: (BuildContext context) {
//        // return object of type Dialog
//        return AlertDialog(
//          title: new Text("Verify your account"),
//          content: new Text("Please verify account in the link sent to email"),
//          actions: <Widget>[
//            new FlatButton(
//              child: new Text("Resent link"),
//              onPressed: () {
//                Navigator.of(context).pop();
//                _resentVerifyEmail();
//              },
//            ),
//            new FlatButton(
//              child: new Text("Dismiss"),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }

//  void _showVerifyEmailSentDialog() {
//    showDialog(
//      context: context,
//      builder: (BuildContext context) {
//        // return object of type Dialog
//        return AlertDialog(
//          title: new Text("Verify your account"),
//          content: new Text("Link to verify account has been sent to your email"),
//          actions: <Widget>[
//            new FlatButton(
//              child: new Text("Dismiss"),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }






















  void _signOut() async {
    try {
      await widget.auth.signOut();
      widget.onSignOut();
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {

    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return new MaterialApp(

        debugShowCheckedModeBanner: false,

        home: new Scaffold(
          backgroundColor: Color.fromRGBO(4, 4, 4, 1),
          body: Container(

             /* Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/images/wave.gif'),
                        fit: BoxFit.fill
                    )
                ),
                width: 200,
                height: 100,),
*/            child: Container(
                color: Color.fromRGBO(4, 4, 4, 1),

                child: new Stack(
                  children: <Widget>[


                    Container(
                      color: Colors.transparent,
                      child: new Column(
                        children: <Widget>[
                          SizedBox(height: 50,),
                          Container(
                            child: Image.asset("assets/images/logo.png", height: height/5,
                              width: width,),
                          ),
                          FlatButton(
                              child: new Text('Logout',
                                  style: new TextStyle(fontSize: 17.0, color: Colors.white)),
                              onPressed: _signOut ),
                          FutureBuilder<Track>(
                            future: getTrack(),
                            builder: (context , snapshot){
                              if(snapshot.hasData){
                                final track = snapshot.data;

                                return Text("Track : ${track.currenttrack}", style: TextStyle(color: Colors.white, fontSize: 20),);
                              }else if(snapshot.hasError){
                                    return Text(snapshot.error.toString());
                              }
                              return CircularProgressIndicator();
                            },
                          ),
                          Container(
                            child: Image.asset("assets/images/wave.gif", height: height/3,
                              width: width,),
                          ),
                          Expanded(
                            flex: 2,
                            child: Padding(
                              padding: const EdgeInsets.only(right: 80),
                              child: Align(
                                alignment: FractionalOffset.center,
                                child: IconButton(icon: isPlaying? Icon(
                                  Icons.pause_circle_outline,
                                  size: 120,
                                  color: Colors.white,
                                )
                                    : Icon(
                                  Icons.play_circle_outline,
                                  color: Colors.white,
                                  size: 120,
                                ),
                                  onPressed: (){
                                    setState(() {
                                      FlutterRadio.play(url: url);
                                      isPlaying = !isPlaying;
                                      isVisible = !isVisible;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ),

                          SizedBox(height: 50,)
                        ],
                      ),
                    ),


                  ],
                ),
              ),


          )
        ));

  }
}
Future<Track> getTrack() async{
  final url = "https://public.radio.co/stations/scc370f2b2/status";
  final response = await http.get(url);

 if(response.statusCode ==200){
    String jsonTrack = jsonDecode(response.body);

    return Track.fromJson(jsonTrack);
  }else {
    throw Exception();
  }




}

/* ,*/
