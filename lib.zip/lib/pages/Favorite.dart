import 'package:flutter/material.dart';
class Favorite extends StatefulWidget {
  @override
  _FavoriteState createState() => _FavoriteState();
}

class _FavoriteState extends State<Favorite> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(4, 4, 4, 1),
      appBar: new AppBar(
        title: const Text('Favorite'),
        centerTitle: true,
      ),
    );
  }
}
